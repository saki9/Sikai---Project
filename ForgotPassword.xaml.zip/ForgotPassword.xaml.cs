﻿using System.Windows;
using System.Windows.Input;

namespace Sikai_Project
{
	public partial class ForgotPassword : Window
	{
		public ForgotPassword()
		{
			InitializeComponent();
		}

		private void ResetPassword_Click(object sender, RoutedEventArgs e)
		{
			string newPassword = NewPasswordBox.Password;
			string confirmPassword = ConfirmPasswordBox.Password;

			bool isValid = true;

			if (string.IsNullOrWhiteSpace(EmailBox.Text))
			{
				EmailError.Visibility = Visibility.Visible;
				isValid = false;
			}
			else
			{
				EmailError.Visibility = Visibility.Collapsed;
			}

			if (newPassword.Length < 6)
			{
				NewPasswordError.Visibility = Visibility.Visible;
				isValid = false;
			}
			else
			{
				NewPasswordError.Visibility = Visibility.Collapsed;
			}

			if (newPassword != confirmPassword)
			{
				ConfirmPasswordError.Visibility = Visibility.Visible;
				isValid = false;
			}
			else
			{
				ConfirmPasswordError.Visibility = Visibility.Collapsed;
			}

			if (!isValid)
				return;

			MessageBox.Show(
				"Your password has been reset successfully!",
				"SIKAI",
				MessageBoxButton.OK,
				MessageBoxImage.Information);

			LoginWindow loginWindow = new LoginWindow();
			loginWindow.Show();

			Close();
		}

		private void BackToLogin_Click(object sender, MouseButtonEventArgs e)
		{
			LoginWindow loginWindow = new LoginWindow();
			loginWindow.Show();

			Close();
		}
	}
}
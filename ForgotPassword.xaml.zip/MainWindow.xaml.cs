﻿using System.Windows;
using System.Windows.Controls;

namespace Sikai_Project
{
	public partial class MainWindow : Window
	{
		private bool _syncingPassword1;
		private bool _syncingPassword2;

		public MainWindow()
		{
			InitializeComponent();
		}

		private void PasswordBox1_PasswordChanged(object sender, RoutedEventArgs e)
		{
			if (_syncingPassword1) return;

			_syncingPassword1 = true;
			PasswordTextBox1.Text = PasswordBox1.Password;
			_syncingPassword1 = false;
		}

		private void PasswordTextBox1_TextChanged(object sender, TextChangedEventArgs e)
		{
			if (_syncingPassword1) return;

			_syncingPassword1 = true;
			PasswordBox1.Password = PasswordTextBox1.Text;
			_syncingPassword1 = false;
		}

		private void ShowPasswordToggle1_Checked(object sender, RoutedEventArgs e)
		{
			bool show = ShowPasswordToggle1.IsChecked == true;

			PasswordTextBox1.Visibility = show ? Visibility.Visible : Visibility.Collapsed;
			PasswordBox1.Visibility = show ? Visibility.Collapsed : Visibility.Visible;
		}

		private void PasswordBox2_PasswordChanged(object sender, RoutedEventArgs e)
		{
			if (_syncingPassword2) return;

			_syncingPassword2 = true;
			PasswordTextBox2.Text = PasswordBox2.Password;
			_syncingPassword2 = false;
		}

		private void PasswordTextBox2_TextChanged(object sender, TextChangedEventArgs e)
		{
			if (_syncingPassword2) return;

			_syncingPassword2 = true;
			PasswordBox2.Password = PasswordTextBox2.Text;
			_syncingPassword2 = false;
		}

		private void ShowPasswordToggle2_Checked(object sender, RoutedEventArgs e)
		{
			bool show = ShowPasswordToggle2.IsChecked == true;

			PasswordTextBox2.Visibility = show ? Visibility.Visible : Visibility.Collapsed;
			PasswordBox2.Visibility = show ? Visibility.Collapsed : Visibility.Visible;
		}

		private void SignUp_Click(object sender, RoutedEventArgs e)
		{
			bool isValid = true;

			if (string.IsNullOrWhiteSpace(FullNameBox.Text))
			{
				FullNameError.Visibility = Visibility.Visible;
				isValid = false;
			}
			else
			{
				FullNameError.Visibility = Visibility.Collapsed;
			}

			if (string.IsNullOrWhiteSpace(EmailBox.Text) || !EmailBox.Text.Contains("@"))
			{
				EmailError.Visibility = Visibility.Visible;
				isValid = false;
			}
			else
			{
				EmailError.Visibility = Visibility.Collapsed;
			}

			if (PasswordBox1.Password.Length < 6)
			{
				PasswordError.Visibility = Visibility.Visible;
				isValid = false;
			}
			else
			{
				PasswordError.Visibility = Visibility.Collapsed;
			}

			if (PasswordBox2.Password != PasswordBox1.Password ||
				string.IsNullOrEmpty(PasswordBox2.Password))
			{
				ConfirmPasswordError.Visibility = Visibility.Visible;
				isValid = false;
			}
			else
			{
				ConfirmPasswordError.Visibility = Visibility.Collapsed;
			}

			if (!isValid)
				return;

			string role = TeacherRole.IsChecked == true ? "Teacher" : "Student";

			MessageBox.Show(
				$"Account created successfully as a {role}!",
				"SIKAI",
				MessageBoxButton.OK,
				MessageBoxImage.Information);

			LoginWindow loginWindow = new LoginWindow();
			loginWindow.Show();

			Close();
		}

		private void Login_Click(object sender, RoutedEventArgs e)
		{
			LoginWindow loginWindow = new LoginWindow();
			loginWindow.Show();

			Close();
		}
	}
}
﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Sikai_Project
{
	public partial class LoginWindow : Window
	{
		private bool _syncingPassword;

		public LoginWindow()
		{
			InitializeComponent();
		}

		private void PasswordBox1_PasswordChanged(object sender, RoutedEventArgs e)
		{
			if (_syncingPassword)
				return;

			_syncingPassword = true;
			PasswordTextBox1.Text = PasswordBox1.Password;
			_syncingPassword = false;
		}

		private void PasswordTextBox1_TextChanged(object sender, TextChangedEventArgs e)
		{
			if (_syncingPassword)
				return;

			_syncingPassword = true;
			PasswordBox1.Password = PasswordTextBox1.Text;
			_syncingPassword = false;
		}

		private void ShowPasswordToggle1_Checked(object sender, RoutedEventArgs e)
		{
			bool showPassword = ShowPasswordToggle1.IsChecked == true;

			PasswordTextBox1.Visibility = showPassword ? Visibility.Visible : Visibility.Collapsed;
			PasswordBox1.Visibility = showPassword ? Visibility.Collapsed : Visibility.Visible;
		}

		private void Login_Click(object sender, RoutedEventArgs e)
		{
			bool isValid = true;

			if (string.IsNullOrWhiteSpace(EmailBox.Text))
			{
				EmailError.Visibility = Visibility.Visible;
				isValid = false;
			}
			else
			{
				EmailError.Visibility = Visibility.Collapsed;
			}

			if (string.IsNullOrWhiteSpace(PasswordBox1.Password))
			{
				PasswordError.Visibility = Visibility.Visible;
				isValid = false;
			}
			else
			{
				PasswordError.Visibility = Visibility.Collapsed;
			}

			if (!isValid)
				return;

			MessageBox.Show(
				"Logged in successfully!",
				"SIKAI",
				MessageBoxButton.OK,
				MessageBoxImage.Information);
		}

		private void ForgotPassword_Click(object sender, RoutedEventArgs e)
		{
			ForgotPassword forgotPassword = new ForgotPassword();
			forgotPassword.Show();
			Close();
		}

		private void SignUpLink_Click(object sender, RoutedEventArgs e)
		{
			MainWindow signUpWindow = new MainWindow();
			signUpWindow.Show();
			Close();
		}
	}
}